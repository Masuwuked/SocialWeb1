1. Tweets
    -> Creating
        -> Text
        -> Image
    -> Delete
    -> Retweeting

2. Users
    -> Register
    -> Login
    -> Logout
    -> Profile
        -> Image?
        -> Text?
        -> Follow Button
    -> Feed
        -> User's feed only?
        -> User + who they follow?

3. Following / Followers


Long term todos
- Notifications
- DM
- Explore -> finding hashtags
