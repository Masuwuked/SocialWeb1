# Tweetme 2
Build a twitter-like app in Django, Bootstrap, Javascript, & React.js. Step-by-Step.

> **This project is Coming Soon.**

### Lesson Code
_Lessons 1-5: no significant code added_

[6 - Updated VS Code Config](../../tree/c118bac532475dc16052c0ce5dce2d264d5c333a/)

[7 - Our Roadmap](../../tree/c51618fea2bf4e7af336d1377d31b5ce4c376217/)

[8 - The Tweets Model](../../tree/84a3ef90feeefa9e99264e832b0c73e4ded950a6/)

[9 - Store Data from Django Model](../../tree/c08ef2bb515709610161838223b0b16fc0fc4cf3/)

